package com.company;

public class User {


    private String userNameCheck;
    private String passwordCheck;
    private String userName = "test";
    private String password = "test123";

    public String getUserNameCheck() {
        return userNameCheck;
    }

    public void setUserNameCheck(String userNameCheck) {
        this.userNameCheck = userNameCheck;
    }

    public String getPasswordCheck() {
        return passwordCheck;
    }

    public void setPasswordCheck(String passwordCheck) {
        this.passwordCheck = passwordCheck;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
