package com.company;

import java.util.Scanner;

public class LoginPanel extends User {

    Scanner userInput = new Scanner(System.in);
    boolean flag;

    public void credentials() {

        System.out.println("Input your username:");
        setUserNameCheck(userInput.next());

        System.out.println("Input your password:");
        setPasswordCheck(userInput.next());

        try {
            if (getUserNameCheck().equals(getUserName()) && getPasswordCheck().equals(getPassword())) {
                System.out.println("\nWelcome " + getUserName() + ",\n");
                flag = true;

            } else {
                System.out.println("\nUser doesn't exist.");
                credentials();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

