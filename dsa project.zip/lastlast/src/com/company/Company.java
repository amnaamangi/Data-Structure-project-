package com.company;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Company {

    static String RecordFound = "";
    static String fileName = "Employee's Record.txt";
    static String tempFileName = "Temp Employee's Record.txt";

    Scanner scan = new Scanner(System.in).useDelimiter("\n");
    ArrayList<Employee> employeeArrayList = new ArrayList<>();

    public void loginCheck() throws IOException {
        LoginPanel login = new LoginPanel();

        login.credentials();

        if (login.flag)
            menu();

    }

    public void menu() throws IOException {

        int choice;
        int T = 1;
        while (T == 1) {
            System.out.println("""

                    Welcome to Employee Record Management System

                    Press
                    1 to create an Employee Record
                    2 to delete an Employee record
                    3 to Search an Employee Record
                    4 to view all Records
                    5 to Exit
                    """);
            System.out.println("Enter: \n");
            choice = scan.nextInt();

            if (choice == 1) {
                insertRecord();
            } else if (choice == 2) {
                System.out.println("Enter Employee's Id to delete record.\n");
                String idRemove = scan.next();
                deleteRecord(idRemove);
            } else if (choice == 3) {
                System.out.println("Enter Employee's Id to search record.\n");
                String idSearch = scan.next();
                searchRecord(idSearch);
            } else if (choice == 4) {
                showRecords();
            } else if (choice == 5) {
                System.exit(0);
            } else {
                System.out.println("invalid choice.\n");
            }
            System.out.println("Return to Main Menu Press 1");
            T = scan.nextInt();
            if (T == 1) {
                menu();
            }
        }
    }

    public void insertRecord() throws IOException {
        System.out.println("Enter Employee's Name: ");
        String name = scan.next();
        System.out.println("Enter Employee's Id: ");
        String id = scan.next();

        System.out.println("Enter Employee's designation: ");
        String designation = scan.next();
        System.out.println("Enter Employee's Salary: ");
        String salary = scan.next();

        Employee employee = new Employee(id, name, designation, salary);

        employeeArrayList.add(employee);

        writingToFile(employee);

    }

    public void deleteRecord(String id) {
        int lineNumber;
        ArrayList<String> fileData = new ArrayList<>();

        try {
            FileReader readFile = new FileReader(fileName);
            BufferedReader readBuffer = new BufferedReader(readFile);
            for (lineNumber = 0; lineNumber <= TotalLines()-1;) {
                fileData.add(readBuffer.readLine());
                String specificID = fileData.get(lineNumber).substring(0,2);
                if(specificID.equals(id)){
                    RecordFound = fileData.get(lineNumber);
                    break;
                }
                lineNumber++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            File inputFile = new File(fileName);
            if (!inputFile.isFile()) {
                System.out.println("File does not exist");
                return;
            }
            File tempFile = new File(tempFileName);
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
            String line;

            while ((line = br.readLine()) != null) {
                if (!line.trim().equals(RecordFound)) {
                    pw.println(line);
                    pw.flush();
                }
            }
            System.out.println("Record deleted: " + RecordFound);
            pw.close();
            br.close();

            if (!inputFile.delete()) {
                fileName = tempFileName;
                System.out.println("Could not delete file");
                return;
            }

            if (!tempFile.renameTo(inputFile))
                System.out.println("Could not rename file");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void searchRecord(String ID){
        int lineNumber;
        ArrayList<String> fileData = new ArrayList<>();

        try {
            FileReader readFile = new FileReader(fileName);
            BufferedReader readBuffer = new BufferedReader(readFile);
            for (lineNumber = 0; lineNumber <= TotalLines()-1;) {
                fileData.add(readBuffer.readLine());
                String specificID = fileData.get(lineNumber).substring(0,2);
                if(specificID.equals(ID)){
                    System.out.println("Record Found: " + fileData.get(lineNumber));
                    RecordFound = fileData.get(lineNumber);
                    break;
                }
                lineNumber++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showRecords(){

        System.out.printf("%-5s %-20s %-20s %-5s\n%n%n", "ID", "Name", "Designation", "Salary");

        try{
            File obj = new File(fileName);
            Scanner myReader = new Scanner(obj);
            while (myReader.hasNextLine()){
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        }catch (FileNotFoundException e){
            System.out.println("An error occurred");
            e.printStackTrace();
        }
    }

    public static int TotalLines(){
        int lines = 0;
        try{
            Path path = Paths.get(fileName);
            lines = (int) Files.lines(path).count();
        }
        catch(IOException e){
            System.out.println(e);
        }
        return lines;
    }

    public void writingToFile(Employee employee) throws IOException {
        try (FileWriter fw = new FileWriter(fileName, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {

            out.write(String.format("%-5s %-20s %-20s %-5s\n", employee.getId(), employee.getName(), employee.getDesignation(), employee.getSalary()));
            out.close();
            System.out.println("Writing to file successful");
        }
    }


}
